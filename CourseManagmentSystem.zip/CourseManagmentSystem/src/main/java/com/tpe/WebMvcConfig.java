package com.tpe;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.view.InternalResourceViewResolver;
import org.springframework.web.servlet.view.JstlView;

@Configuration
@EnableWebMvc  //it is enable MVC config
@ComponentScan("com.tpe") //it is scan all components
public class WebMvcConfig implements WebMvcConfigurer {
	
	@Bean// We use viewResolver to bring the view  visible to the user
	public InternalResourceViewResolver resolver() {
		InternalResourceViewResolver resolver=new InternalResourceViewResolver();
		resolver.setViewClass(JstlView.class); //it helps to write  jsp files by writing less java code
		resolver.setPrefix("/WEB-INF/views/"); //specify the location  of file
		resolver.setSuffix(".jsp"); //use files with java server page extension
		return resolver;
	}


	//The addResourceHandlers() method is an override of a method from the
	// WebMvcConfigure interface in Spring MVC
	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) { //path for files like css,style,image
		registry.addResourceHandler("/resources/**").
				addResourceLocations("/resources/").setCachePeriod(0);
	}

}
