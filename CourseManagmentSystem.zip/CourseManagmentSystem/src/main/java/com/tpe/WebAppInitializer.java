package com.tpe;

import org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer;

public class WebAppInitializer extends AbstractAnnotationConfigDispatcherServletInitializer {

	@Override // db and hibernate related configurations
	protected Class<?>[] getRootConfigClasses() {
		return new Class[] {
             RootContextConfig.class
			};
	}

	@Override //Spring MVC config settings-class with bean definitions
	protected Class<?>[] getServletConfigClasses() {
		return new Class[] {
			WebMvcConfig.class
		};
	}

	@Override //which url will be associated with  servlet
	protected String[] getServletMappings() {
		return new String[] {"/"};
	}



}
